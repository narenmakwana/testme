import { ParamtestPage } from './app.po';

describe('paramtest App', () => {
  let page: ParamtestPage;

  beforeEach(() => {
    page = new ParamtestPage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});

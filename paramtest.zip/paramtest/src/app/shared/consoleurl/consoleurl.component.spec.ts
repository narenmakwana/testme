import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConsoleurlComponent } from './consoleurl.component';

describe('ConsoleurlComponent', () => {
  let component: ConsoleurlComponent;
  let fixture: ComponentFixture<ConsoleurlComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConsoleurlComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConsoleurlComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

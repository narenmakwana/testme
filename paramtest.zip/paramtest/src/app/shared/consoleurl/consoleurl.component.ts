import {Component,Input,Output,OnInit} from '@angular/core'
import {ConsoleUrlService} from '../service/consoleurl.service';

@Component({
  selector: 'app-consoleurl',
  templateUrl: './consoleurl.component.html',
  styleUrls: ['./consoleurl.component.css'],
  providers: [ConsoleUrlService]

})
export class ConsoleurlComponent implements OnInit {

  @Input() value: string;

  constructor(private consoleUrlService: ConsoleUrlService) { 

    this.consoleUrlService.getConsoleUrls(this.value);
  }

  ngOnInit() {

    console.log(this.value);
  }

}

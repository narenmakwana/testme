import {Component,Input,Output} from '@angular/core'
import {Injectable} from '@angular/core';
import {Http,Response} from '@angular/http';
import 'rxjs/add/operator/map';

@Injectable()

export class ConsoleUrlService { 
     @Input() value: string;
     url: string;
     name:string;
     file:string;

    constructor(private http: Http) {
           console.log('ConsoleUrlService Initilized');
           
    }

    getConsoleUrls(name:string){ 
    
        console.log("inside getConsoleUrls service function");
        console.log("value pass in service is"  + this.name);
    }
     
}


import { TestBed, inject } from '@angular/core/testing';

import { ConsoleurlService } from './consoleurl.service';

describe('ConsoleurlService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [ConsoleurlService]
    });
  });

  it('should ...', inject([ConsoleurlService], (service: ConsoleurlService) => {
    expect(service).toBeTruthy();
  }));
});

module.exports = function(PriceHelper) {

  PriceHelper.lookupPrice = function(productId, callback) {
    require('function-rate-limit')(5, 1000, PriceHelper.price(productId,function(err, result){
          callback(err, result);
    }));
  };
};

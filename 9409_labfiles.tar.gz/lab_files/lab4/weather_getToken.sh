# Change the following variables: cid, secret, url
cid=403fb98d-8969-4684-b2ce-23aafd72ece8
secret=sQ0nF2sE3vS7uQ7vX8xM0pK3iV8qP0mF5vV6oT4uY8bU4yA5nI
url=https://api.us.apiconnect.ibmcloud.com/cbornertukibmcom-aspace/sb/oauth2/token

# Static variables: scope, username, password
scope=weather
username=weathermobileapp
password=Passw0rd!

# Screen output:
echo
echo "#########################################################"
echo "The curl command which is actually run is the following: "
echo
echo "curl -u ${cid}:${secret} -k -X POST -d "\'grant_type=password\&scope=${scope}\&username=${username}\&password=${password}\'" "${url}""
echo 
echo "#########################################################"
echo "Response: "
echo

# Actual curl command:
curl -u ${cid}:${secret} -k -X POST -d "grant_type=password&scope=${scope}&username=${username}&password=${password}" ${url} --insecure
echo
echo
# Done.
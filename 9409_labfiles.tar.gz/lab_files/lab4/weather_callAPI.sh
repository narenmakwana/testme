# Change the following variables: cid, secret, url
cid=403fb98d-8969-4684-b2ce-23aafd72ece8
token=YOUR_TOKEN_HERE
weather_api_url=https://api.us.apiconnect.ibmcloud.com/cbornertukibmcom-aspace/sb/weather/city/REPLACE_LOCATION

# Screen output:
echo
echo "#########################################################"
echo "The curl command which is actually run is the following: "
echo
echo "curl -k -H \"X-IBM-Client-Id: ${cid}\" -H \"Authorization: Bearer ${token}\" -X GET ${weather_api_url} --insecure"
echo 
echo "#########################################################"
echo "Response: "
echo

# Actual curl command:
echo
curl -k -H "X-IBM-Client-Id: ${cid}" -H "Authorization: Bearer ${token}" -X GET ${weather_api_url} --insecure
echo
echo
# Done.
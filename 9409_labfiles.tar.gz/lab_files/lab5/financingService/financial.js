/*eslint-env node*/

//------------------------------------------------------------------------------
// node.js starter application for Bluemix
//------------------------------------------------------------------------------

var http = require('http');
var soap = require('soap');
var math = require('mathjs');
var url = require('url');

// cfenv provides access to your Cloud Foundry environment
// for more info, see: https://www.npmjs.com/package/cfenv
var cfenv = require('cfenv');

// get the app environment from Cloud Foundry
//var SECURITYPORT = cfenv.getAppEnv();
var SECURITYPORT = 1234;

//We need a function which handles requests and send response
function securityHandleRequest(request, response){
    console.log("Service has been called on %s", request.url);
    var indexWeather = request.url.indexOf("/weather/");
	var indexCalculate = request.url.indexOf("/calculate");
	//console.log('indexWeather ' + indexWeather);
	if(indexWeather>=0){
		console.log('Weather found' + request.url);
		var weatherLocation = request.url.substring(indexWeather);
		http.get({
			host: 'api.openweathermap.org',
			path: '/data/2.5/weather?q='+weatherLocation+'&units=imperial&APPID=4a64636948ffe2d767fc96cdab773f49'
		}, function(getResponse) {
			// Continuously update stream with data
			var body = '';
			getResponse.on('data', function(d) {
				body += d;
			});
			getResponse.on('end', function() {
				// Data reception is done, do whatever with it!
				response.setHeader('Content-Type', 'application/json');
				response.end(body);
        });
    });
	}
	else if (indexCalculate>=0){
		var calURL = url.parse(request.url, true);
		var company = calURL.query.company;
		var toZip = calURL.query.from_zip;
		var fromZip = calURL.query.to_zip;
		console.log('Calculate found' + company +' and '+ toZip + fromZip);
		
		
		var price = (fromZip + toZip)/10000;
        price = (company == "xyz") ? price * 1.1 : price;

        var replyObj = {
           company: company,
           rates: {
              next_day: Number(price * 1.9).toFixed(2),
              two_day: Number(price * 1.3).toFixed(2),
              ground: Number(price).toFixed(2)
            }
		}
		response.setHeader('Content-Type', 'application/json');
		response.end(JSON.stringify(replyObj));
	}
	else{
		response.end('It Works!! Path Hit: ' + request.url);
	}
}

//Create a server
var securityServer = http.createServer(securityHandleRequest);

//Lets start our server
securityServer.listen(SECURITYPORT, function(){
    //Callback triggered when server is successfully listening. Hurray!
    console.log("Server listening on: http://localhost:%s", SECURITYPORT);
});

var xml = require('fs').readFileSync('financial.wsdl', 'utf8');

var soapService = {
    financingService: {
        financingPort: {
            financing : function(args) {
                console.log("Service has been called");
                var amount = args.amount;
                var rate =  args.rate;
                var duration = args.duration;
                var J = math.eval(rate / 1200);
                console.log("Service has been called %s", J);
                //var K = math.eval(1 + J);
                //console.log("Monthly rate %s", K);
                console.log("Duration %s", duration);
                var compRate = math.eval(duration*J);
                console.log("Overall component rate= %s", compRate);
                var quote = math.eval(amount * (1+compRate));
                //var paymentAmount = math.eval((quote * 100) / 100); 
                return { paymentAmount : quote };
            }

        }
    }
}

soap.listen(securityServer, '/financial', soapService, xml);
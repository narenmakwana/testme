module.exports = function(app, cb) {
    var ds = app.dataSources.productSOAP;
    if (ds.connected) {
        var products = ds.createModel('Products', {}, {base: 'Model'});
        app.model(products);
        process.nextTick(cb);
    } else {
        ds.once('connected', function() {
            var products = ds.createModel('Products', {}, {base: 'Model'});
            app.model(products);
            cb();
        });
    }
};

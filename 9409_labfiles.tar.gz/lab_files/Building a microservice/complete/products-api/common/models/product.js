var async = require("async");

module.exports = function(Product) {
  /**
   * Find all instances of the model matched by filter from the Product source.
   * @param {object} filter Filter defining fields, where, include, order, offset, and limit
   * @param {Function(Error, object)} callback
   */
  Product.find = function(filter, callback) {
    console.log('Product->find: filter(%s)', filter);
    var data = [];
    // -------------------------------------------------
    // sequentially call
    // 1) the SOAP service to get all products,
    // 2) then the REST service on each product
    // 3) finally get the review from mongo
    async.waterfall([
        getProducts,
        getPriceForEachProduct,
        getReviewsForEachProduct
      ], function (error, data) {
        if (error) {
          console.log('Product->find: Error: %s', error);
          return callback(error, null);
        }
        console.log('products: ', data);
        return callback(null, data);
      }
    );
  };

  // -----------------------------------------------------
  //invoke SOAP to retrieve all the products in the catalog
  var getProducts = function (next) {
    var catalog = Product.app.models.Products;
    catalog.inventory(function (err, inventory) {
      if (err) {
        return next(err);
      }
      console.log('Product->find: Inventory from SOAP service: ', inventory);
      next(err, inventory.return);
    })
  };

  // -----------------------------------------------------
  // get Price for each product
  var getPriceForEachProduct = function (products, next) {
    async.each(products, getPrice, function (err) {
      next(err, products);
    })
  };

  // -----------------------------------------------------
  //invoke REST to set price for each product in the catalog
  var getPrice = function (product, callback) {
    console.log('Product->find: before calling REST for %s', product.id);
    var priceHelper = Product.app.models.PriceHelper;
    priceHelper.lookupPrice(product.id, function (err, ret) {
      if (err) {
        console.log('Error: (%s)', err);
      }
      //add price to the product:
      product.price = ret.price;
      //done
      callback();
    });
  };

  // --------------------------------------------------------
  // get Reviews for each product
  var getReviewsForEachProduct = function (products, next) {
    async.each(products, getReviews, function (err) {
      next(err, products);
    })
  };

  // --------------------------------------------------------
  //retrieve the Reviews directly from the mongo database
  var getReviews = function (product, callback) {
    var reviews = Product.app.models.review;
    reviews.find({ where: {productId:product.id} },
      function(err, revs){
        console.log("reviews for "+product.id);
        console.log(revs);
        product.rating = calculateRating(revs);
        console.log("product:", product);
        //done
        callback();
      }
    );
  };

  // --------------------------------------------------------
  //calculate the rating based on the given reviews
  var calculateRating = function (reviews) {
    var rating = 0; // Default rating
    console.log(reviews);
    var reviewCount = reviews.length;
    if(reviews && (reviewCount > 0)){
      var ratingSum = 0;

      // Sum all the review scores
      for (var i = 0; i < reviewCount; i++) {
        ratingSum += reviews[i].rating;
      }
      // Take an average of all the review scores
      rating = Math.round((ratingSum / reviewCount) * 100) / 100;
    }
    return rating;
  };

  // ------------------------------------------------
  /**
   * Find a product by id.
   * @param {string} id of the product to find.
   * @param {Function(Error, object)} callback
   */
  Product.findById = function(id, callback) {
    var catalog = Product.app.models.Products;
    catalog.inventory(function (err, inventory) {
      if (err) {
        callback(err);
      }else{
        console.log('Product-&gt;find: Inventory from SOAP service: ', inventory);
        inventory.return.forEach(function(element){
          if(element.id === id){
            callback(null, element);
          }
        });
        callback(null, {"id":id, "description":"Product with id: "+id+" was not found.", "name":"Not found."});
      }
    })
  };

  // ------------------------------------------------
  /**
   * Find the reviews for the given product id.
   * @param {string} id Id of the product to find the reviews of.
   * @param {Function(Error, array)} callback
   */
  Product.findReviewsById = function(id, callback) {
    var reviews = Product.app.models.review;
    reviews.find({ where: {productId:id} }, function(err, data){
      if (err) {
        callback(err);
      }else{
        console.log("reviews for "+id);
        console.log(data);
        //done
        callback(err, data);
      }
    });
  };

};

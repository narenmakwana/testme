/**
 * AccountProfileDataBean.java
 *
 * This file was auto-generated from WSDL
 * by the IBM Web services WSDL2Java emitter.
 * o0526.04 v62905175048
 */

package org.apache.geronimo.samples.daytrader;

public class AccountProfileDataBean  {
    private java.lang.String userID;
    private java.lang.String password;
    private java.lang.String fullName;
    private java.lang.String address;
    private java.lang.String email;
    private java.lang.String creditCard;

    public AccountProfileDataBean() {
    }

    public java.lang.String getUserID() {
        return userID;
    }

    public void setUserID(java.lang.String userID) {
        this.userID = userID;
    }

    public java.lang.String getPassword() {
        return password;
    }

    public void setPassword(java.lang.String password) {
        this.password = password;
    }

    public java.lang.String getFullName() {
        return fullName;
    }

    public void setFullName(java.lang.String fullName) {
        this.fullName = fullName;
    }

    public java.lang.String getAddress() {
        return address;
    }

    public void setAddress(java.lang.String address) {
        this.address = address;
    }

    public java.lang.String getEmail() {
        return email;
    }

    public void setEmail(java.lang.String email) {
        this.email = email;
    }

    public java.lang.String getCreditCard() {
        return creditCard;
    }

    public void setCreditCard(java.lang.String creditCard) {
        this.creditCard = creditCard;
    }

}
